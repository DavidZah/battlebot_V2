#include <atmel_start.h>
#include "avr/delay.h"



uint32_t readRSense(){
	
	uint32_t x = 0; 
	
	TRIG_R_set_level(true); 
	_delay_us(15); 
	TRIG_R_set_level(false); 
	while(!ECHO_R_get_level()&&x < 1000){
		x++;
	}
	while(ECHO_R_get_level()&&x < 1000){ 
		x++; 
	}
	return x; 
}
uint32_t readLSense(){
	
	uint32_t x = 0; 
	
	TRIG_L_set_level(true); 
	_delay_us(15); 
	TRIG_L_set_level(false); 
	while(!ECHO_L_get_level()&&x < 1000){
		x++;
	}
	while(ECHO_L_get_level()&&x < 1000){ 
		x++; 
	}
	return x; 
}
uint32_t readFSense(){
	
	uint32_t x = 0; 
	
	TRIG_F_set_level(true); 
	_delay_us(15); 
	TRIG_F_set_level(false); 
	while(!ECHO_F_get_level()&&x < 1000){
		x++;
	}
	while(ECHO_F_get_level()&&x < 1000){ 
		x++; 
	}
	return x; 
}

bool on_line(){
	int x = ADC_0_get_conversion(4); 
	int y = ADC_0_get_conversion(5); 
	if(x > 500 || y > 500){
		return true; 
	}
	return true; 
}
void setMotorSpeed(int left, int right){
	 if(left < 256){
      IN1_set_level(true); 
	  IN2_set_level(false); 
		OCR2A = left;  
      }
    if(left > 256){
		IN1_set_level(false); 
		IN2_set_level(true); 
		OCR2A = left-255;  
      }
    if(left == 256){
      OCR2A = 0; 
      }
      
    if(right < 256){
      IN3_set_level(true); 
	  IN4_set_level(false); 
	  OCR2B = right;  
      }
    if(right > 256){
       IN3_set_level(true); 
	   IN4_set_level(false); 
	   OCR2B = right - 255; 
      }
    if(right == 256){
       OCR0A = 0; 
      }
}

int scan(){
	int x = readRSense(); 
	if (x < 700)
	{
		return 0; 
	}
	x = readFSense(); 
	if (x < 700)
	{
		return 1; 
	}
	x = readFSense(); 
	if (x < 700)
	{
		return 2; 
	}
	return 100; 
}

int turn(){
	setMotorSpeed(256,350); 
	for (int i = 0;i < 50&&on_line(); i++){
		_delay_us(100);
		int x = scan(); 
		if(x !=100){
			return x ;
		}
	}
	return 100; 
}


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
	
		/*
	      int i= 0;
		  int x = turn(); 
		  while(i > 100 && x == 100 && on_line()){
			  setMotorSpeed(300,300); 
			  _delay_us(40); 
			  i++; 
		  }
		  setMotorSpeed(0,0);
		  i = 0; 
		  while(i > 100 && !on_line()){
			   setMotorSpeed(150,150);
			   i++;  
		  }
		  i = 0; 
		  setMotorSpeed(0,0);

		  setMotorSpeed(0,0);
		  while(i>200 && on_line && x != 1){
			  setMotorSpeed(256,350);
			  _delay_us(10);
			  x = scan();
			  i++;
		  }
		  setMotorSpeed(0,0);
		  
	
		   while(i>200 && on_line && x != 3){
			   setMotorSpeed(350,256);
			   _delay_us(10);
			   x = scan();
			   i++;
		   }
		   setMotorSpeed(0,0);
		  
		   while(x == 1 && on_line()){
			   setMotorSpeed(500,500);
			   _delay_us(10);
			   x = scan();
			   i++;
		   }
		   */
	}
}
